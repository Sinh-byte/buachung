# BữaChung – Hướng dẫn Build APK

## Cấu trúc thư mục (đã sửa lỗi)

```
lib/
  main.dart
  data/
    models/models.dart          ← Định nghĩa Member, Meal, ...
    db/database.dart            ← SQLite
    repository/
      repository.dart
      app_state.dart            ← ✅ Import đã sửa
  ui/
    screens/
      home_screen.dart          ← ✅ Import meal_detail đã sửa
      add_meal_screen.dart
      other_screens.dart        ← Chứa MealDetailScreen, MembersScreen, SettleScreen
    widgets/
      theme.dart                ← ✅ Export path đã sửa
  utils/
    debt_calculator.dart        ← ✅ Import đã sửa
```

## Các lỗi đã sửa

| File | Lỗi cũ | Đã sửa |
|------|---------|--------|
| `app_state.dart` | `import '../data/models/models.dart'` (sai path) | `import '../models/models.dart'` |
| `debt_calculator.dart` | `import '../models/models.dart'` (sai path) | `import '../data/models/models.dart'` |
| `home_screen.dart` | `import 'meal_detail_screen.dart'` (file không tồn tại) | `import 'other_screens.dart'` |
| `theme.dart` | `export '../data/models/models.dart'` (sai path) | `export '../../data/models/models.dart'` + thêm import |
| `android/settings.gradle` | Cấu trúc Gradle cũ | Plugin management mới (AGP 8.1) |

## Các bước build APK

### Bước 1: Cài đặt Flutter
```bash
# Tải Flutter từ https://flutter.dev/docs/get-started/install
# Thêm vào PATH:
export PATH="$PATH:/đường/dẫn/flutter/bin"

# Kiểm tra:
flutter doctor
```

### Bước 2: Cài đặt Android SDK
```bash
# Tải Android Studio từ https://developer.android.com/studio
# Hoặc cài SDK command line tools
# Sau đó chấp nhận licenses:
flutter doctor --android-licenses
```

### Bước 3: Cập nhật local.properties
```
# File: android/local.properties
flutter.sdk=/home/user/flutter          ← Thay bằng đường dẫn thực
sdk.dir=/home/user/Android/Sdk          ← Thay bằng đường dẫn Android SDK
```

### Bước 4: Get dependencies
```bash
cd buachung
flutter pub get
```

### Bước 5: Build APK
```bash
# APK debug (để test):
flutter build apk --debug

# APK release (để cài):
flutter build apk --release

# File APK sẽ ở:
# build/app/outputs/flutter-apk/app-release.apk
```

### Bước 6: Cài vào điện thoại
```bash
# Bật "Nguồn không rõ" / "Install unknown apps" trên điện thoại
# Kết nối điện thoại qua USB (bật USB debugging):
adb install build/app/outputs/flutter-apk/app-release.apk

# Hoặc copy file APK lên điện thoại và mở bằng file manager
```

## Tính năng của app

- **Bữa ăn**: Thêm bữa ăn với tên quán, ngày, tổng tiền, thành viên tham gia
- **📸 Chụp ảnh**: Mỗi bữa ăn có thể thêm ảnh chụp (camera hoặc gallery) làm bằng chứng
- **Thành viên**: Quản lý danh sách thành viên, xem công nợ từng người
- **Quyết toán**: Tính toán ai cần chuyển tiền cho ai với số giao dịch tối thiểu
- **Lưu cục bộ**: Toàn bộ dữ liệu lưu trong SQLite trên máy, không cần internet
